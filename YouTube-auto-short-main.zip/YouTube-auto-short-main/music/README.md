# 🎵 موسيقى خلفية (Background Music)

هاد المجلد فارغ عمدًا — ماشي مسموح نحملو ملفات صوتية جاهزة هنا (البيئة
لي بنيت فيها هاد المشروع بلا اتصال بالإنترنت أصلاً)، وخاصك تزيدهم بنفسك
من مصادر **مفتوحة/حرة الرخصة** (royalty-free) باش المشروع يبقى قانوني
100% حتى بعد النشر ليوتيوب.

## الهيكل المطلوب

```
music/
  coding/      ← موسيقى هادئة/lo-fi كتدور طول ما الكود كيتكتب على الشاشة
  slide/       ← موسيقى أخف/ambient طول شرائح شرح المفهوم
  execution/   ← صوت قصير (2-3 ثواني: "ding"، نقرة نجاح، whoosh...) كيبان
                 لحظة ما الكود كيتشغل ويطبع النتيجة الحقيقية فالترمينال
```

حط أي عدد ديال ملفات `.mp3` أو `.wav` فكل مجلد — `src/audio_mixer.py`
كيختار وحدة عشوائية من المجلد المناسب فـ كل segment. إذا مجلد معين
خاوي، الرندر كيكمّل عادي بلا موسيقى فهاد الجزء بالضبط (skip تلقائي، ماكاين
حتى خطأ).

المستويات (`MUSIC_VOLUME`, `STINGER_VOLUME` فـ `.env`) معايرة باش
الموسيقى تبقى خافتة تحت صوت الراوي — مقاس شائع فالفيديوهات التعليمية.

## مصادر مقترحة (تحقق من رخصة كل تراك قبل الاستعمال التجاري)

- **YouTube Audio Library** (studio.youtube.com → Audio Library) — أغلب
  التراكات بلا حاجة لـ attribution، مصممة بالضبط لهاد الاستعمال.
- **Pixabay Music** (pixabay.com/music) — royalty-free، بلا attribution.
- **Free Music Archive** (freemusicarchive.org) — رخص CC متنوعة، بعضها
  كيطلب attribution — تحقق من كل تراك.
- **incompetech.com** (Kevin MacLeod) — رخصة CC-BY، خاصك تزيد كريدي
  فوصف الفيديو.
- **Bensound.com** — مجاني مع attribution، أو بدون attribution مقابل
  رخصة مدفوعة.

اقترح: تراكات "lo-fi hip hop" أو "ambient synth" هادئة لـ `coding/`،
تراكات "corporate ambient" ناعمة لـ `slide/`، و"UI success sound" أو
"notification chime" قصيرة لـ `execution/`.
